from pathlib import Path
import engine
from jinja2             import Environment, FileSystemLoader
from jinja2.environment import Template

friends_txt:  str       = Path('friends.txt').read_text().strip()
friends_list: list[str] = friends_txt.split(',')
filename_ejer1: str = 'Invitation_friends.txt'
friend_name: list[str] = friends_list
Esqueleto_invitation = Path ('ESC_invitation.txt').read_text()
ejer1: Path = .ejercicios/'txt'
invitation:         dict = {"invitation_list": zip(friends_list, Esqueleto_invitation)}


engine.fill_template (ejer1,filename_ejer1, invitation) 
