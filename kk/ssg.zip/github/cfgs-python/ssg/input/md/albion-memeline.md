---
title:  Albion on-line
date:   2021-12-01
author: 'Luis, Pau, Denys'
---

![Albion](img/albion-onlnine.png)

>Albion online es un mmorpg no lineal en el que escribes tu propia historia sin limitarte a seguir un camino prefijado, explora un amplio mundo abierto con cinco biomas unicos... -Shaun Lawton
