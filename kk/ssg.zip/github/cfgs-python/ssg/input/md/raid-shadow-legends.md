---
title:  raid shadow legends
date:   2021-12-03
author: Luis, Pau, Denys
---

Pay 2 P(l)ay.

![raid shadow legends](img/raidShadowLegends.png)
