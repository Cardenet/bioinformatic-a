---
title:  rise of kingdoms
date:   2021-12-02
author: Luis, Pau, Denys
---

![rise_of_kingdoms](img/RoK.png)

>¿Que? ¿Qué me destierras? Esta bien no estoy de acuerdo con tus políticas.¡Me largo de acá!. -Doblador del anuncio de Rise of kingdoms
