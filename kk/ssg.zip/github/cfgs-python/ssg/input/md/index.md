---
title:  Principal
date:   2022-02-20
author: Luis, Pau, Denys
---
Esto NO es un top, es una recopilación de los videojuegos que mas memes han generado en
los ultimos años:

[Albion Online](albion-memeline.html)
[Rise of Kingdoms](rise-of-kingdoms.html)
[RAID Shadow Legends](raid-shadow-legends.html)
